﻿using Program1.DataBase;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Program1
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        string captchaText = "";
        int failcaptcha = 0, secondsBlock = 20, fail = 0; int sec = 10;
        DispatcherTimer timerBlock = new DispatcherTimer();
        DispatcherTimer time = new DispatcherTimer();
        Entities entities = new Entities();
        public MainWindow()
        {

            InitializeComponent();
            time.Interval = TimeSpan.FromSeconds(1);
            time.Tick += tim_tick;
            HistoryDG.ItemsSource = entities.Orders.ToList();
            Comboboxclient.ItemsSource = entities.UserClients.ToList();

            ClientDG.ItemsSource = entities.UserClients.ToList();
            ServicesDG.ItemsSource = entities.ServicesTable.ToList();

        }

        private void ExitBtn_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void LoginBtn_Click(object sender, RoutedEventArgs e)
        {
            string login = LoginTXB.Text.ToString();
            string password = PasswordPWB.Password.ToString();

            var proverka = entities.UserWorkers.FirstOrDefault(x => x.WLogin == login && x.WPassWord == password);



            if (proverka == null)
            {
                fail++;
                if (fail == 3)
                {
                    LoginGrid.Visibility = Visibility.Hidden;
                    CaptchaGrid.Visibility = Visibility.Visible;

                    generatorcaptcha();
                    fail = 0;
                }
                else MessageBox.Show("Неверный пароль");
            }
            else
            {
                if (proverka.WRole == 1)
                {
                    LoginGrid.Visibility = Visibility.Collapsed;
                    OrdersHistoryGrid.Visibility = Visibility.Visible;

                }
                else if (proverka.WRole == 2)
                {
                    LoginGrid.Visibility = Visibility.Collapsed;
                    OrderGrid.Visibility = Visibility.Visible;
                }
                else if (proverka.WRole == 3)
                {
                    LoginGrid.Visibility = Visibility.Collapsed;
                    OrderGrid.Visibility = Visibility.Visible;

                }
            }



        }

        private void PasswordCHB_Click(object sender, RoutedEventArgs e)
        {

            if (PassWordTXB.Visibility != Visibility.Visible)
            {
                PassWordTXB.Visibility = Visibility.Visible;
                PasswordPWB.Visibility = Visibility.Collapsed;
            }
            else if (PasswordPWB.Visibility != Visibility.Visible)
            {
                PassWordTXB.Visibility = Visibility.Collapsed;
                PasswordPWB.Visibility = Visibility.Visible;
            }
        }




        private void Button_Click(object sender, RoutedEventArgs e)
        {
            generatorcaptcha();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if (textcaptcha.Text != String.Empty)
            {
                if (textcaptcha.Text.ToLower() == captchaText)
                {
                    textcaptcha.Text = string.Empty;

                    LoginGrid.Visibility = Visibility.Visible;
                    CaptchaGrid.Visibility = Visibility.Hidden;
                }
                else
                {
                    failcaptcha++;
                    generatorcaptcha();
                    if (failcaptcha > 2)
                    {
                        CaptchaGrid.Visibility = Visibility.Hidden;
                        BlockGrid.Visibility = Visibility.Visible;

                        failcaptcha = 0;
                        sec = 10;
                        time.Start();

                    }
                    else MessageBox.Show("Неверная каптча");
                }
            }
            else MessageBox.Show("Введите каптчу");
        }


        public void tim_tick(object sender, EventArgs e)
        {
            BlockTXB.Text = "Система заблокирована. Осталось " + sec.ToString() + " секунд";
            if (sec == 0)
            {
                BlockTXB.Text = string.Empty;
                LoginGrid.Visibility = Visibility.Visible;
                BlockGrid.Visibility = Visibility.Hidden;
                time.Stop();
            }
            sec--;

        }

        private void PasswordCHB_Checked(object sender, RoutedEventArgs e)
        {
            PassWordTXB.Text = PasswordPWB.Password;
        }

        private void PasswordCHB_Unchecked(object sender, RoutedEventArgs e)
        {
            PasswordPWB.Password = PassWordTXB.Text;
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            OrdersHistoryGrid.Visibility = Visibility.Hidden;
            LoginGrid.Visibility = (Visibility)Visibility.Visible;
        }

        private void Comboboxclient_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Получаем выбранный email клиента из ComboBox
            string selectedEmail = Comboboxclient.SelectedValue?.ToString();

            // Проверяем, выбран ли клиент
            if (string.IsNullOrEmpty(selectedEmail))
            {
                // Если клиент не выбран, выводим сообщение и выходим из метода
                MessageBox.Show("Клиент не выбран.");
                return;
            }

            // Выполняем LINQ-запрос для получения заказов, связанных с выбранным клиентом
            var query = (from order in entities.Orders
                         join user in entities.UserClients on order.OClientCode equals user.id // Соединяем таблицы заказов и клиентов
                         where user.CEmail == selectedEmail // Фильтруем по email клиента
                         select order).ToList();

            // Устанавливаем результат запроса в источник данных для DataGrid
            HistoryDG.ItemsSource = query;
        }

        private void ClientsBtn_Click(object sender, RoutedEventArgs e)
        {
            ServicesDG.Visibility = Visibility.Hidden;
            ClientDG.Visibility = (Visibility)Visibility.Visible;
            ClientsBtn.IsEnabled = false;
            ServicesBtn.IsEnabled = true;
        }

        private void ServicesBtn_Click(object sender, RoutedEventArgs e)
        {
            ClientDG.Visibility = (Visibility)Visibility.Hidden;
            ServicesDG.Visibility = (Visibility)Visibility.Visible;
            ClientsBtn.IsEnabled = true;
            ServicesBtn.IsEnabled = false;
        }

        private void SearchTXB_TextChanged(object sender, TextChangedEventArgs e)
        {
            string search = SearchTXB.Text; // Считываем текст из текстового поля для поиска

            // Проверяем, активна ли кнопка "Клиенты"
            if (ClientsBtn.IsEnabled == false)
            {
                // Формируем LINQ-запрос для поиска в таблице "UserClients"
                var query = (from UserClients in entities.UserClients
                             where UserClients.id.ToString().Contains(search) || // Поиск по ID
                             UserClients.CLastName.ToString().Contains(search) || // Поиск по фамилии
                             UserClients.CName.ToString().Contains(search) || // Поиск по имени
                             UserClients.CPatronomic.ToString().Contains(search) || // Поиск по отчеству
                             UserClients.CPassSer.ToString().Contains(search) || // Поиск по серии паспорта
                             UserClients.CPassNum.ToString().Contains(search) || // Поиск по номеру паспорта
                             UserClients.CBirthDate.ToString().Contains(search) || // Поиск по дате рождения
                             UserClients.CIndex.ToString().Contains(search) || // Поиск по индексу
                             UserClients.CCity.ToString().Contains(search) || // Поиск по городу
                             UserClients.CStreet.ToString().Contains(search) || // Поиск по улице
                             UserClients.CStreetNum.ToString().Contains(search) || // Поиск по номеру улицы
                             UserClients.CHomeNum.ToString().Contains(search) || // Поиск по номеру дома
                             UserClients.CEmail.ToString().Contains(search) // Поиск по email
                             select UserClients).ToList();

                // Устанавливаем результат поиска в источник данных для DataGrid
                ClientDG.ItemsSource = query;
            }
            // Проверяем, активна ли кнопка "Услуги"
            else if (ServicesBtn.IsEnabled == false)
            {
                // Формируем LINQ-запрос для поиска в таблице "ServicesTable"
                var query2 = (from ServicesTable in entities.ServicesTable
                              where ServicesTable.id.ToString().Contains(search) || // Поиск по ID
                              ServicesTable.ServName.ToString().Contains(search) || // Поиск по названию услуги
                              ServicesTable.ServCode.ToString().Contains(search) || // Поиск по коду услуги
                              ServicesTable.SerPrice.ToString().Contains(search) // Поиск по цене услуги
                              select ServicesTable).ToList();

                // Устанавливаем результат поиска в источник данных для DataGrid
                ServicesDG.ItemsSource = query2;
            }
        }

        private void ClientAddBtn_Click(object sender, RoutedEventArgs e)
        {
            ClientAddGrid.Visibility = Visibility.Visible;
            OrderGrid.Visibility = Visibility.Collapsed;
        }

        private void ServicesAddBtn_Click(object sender, RoutedEventArgs e)
        {
            ServiceAddGrid.Visibility = Visibility.Visible;
            OrderGrid.Visibility = Visibility.Collapsed;
        }

        private void ExitToLoginBtn_Click(object sender, RoutedEventArgs e)
        {
            OrderGrid.Visibility = Visibility.Hidden;
            LoginGrid.Visibility = (Visibility)Visibility.Visible;
        }

        private void AddBtn_Click(object sender, RoutedEventArgs e)
        {
            // Создаем новый объект клиента
            UserClients userClients = new UserClients();

            // Заполняем свойства объекта клиента данными из текстовых полей
            userClients.id = int.Parse(Code.Text); // ID клиента
            userClients.CLastName = Fam.Text; // Фамилия
            userClients.CStreet = Street.Text; // Улица
            userClients.CEmail = Email.Text; // Email
            userClients.CStreetNum = int.Parse(House.Text); // Номер дома
            userClients.CPassNum = int.Parse(Nom.Text); // Номер паспорта
            userClients.CBirthDate = DateTime.Parse(Birth.Text); // Дата рождения
            userClients.CCity = City.Text; // Город
            userClients.CIndex = int.Parse(Index.Text); // Почтовый индекс
            userClients.CPatronomic = Pat.Text; // Отчество
            userClients.CName = Name.Text; // Имя
            userClients.CPassSer = int.Parse(Ser.Text); // Серия паспорта
            userClients.CHomeNum = int.Parse(Apart.Text); // Номер квартиры

            // Добавляем нового клиента в коллекцию клиентов
            entities.UserClients.Add(userClients);

            // Сохраняем изменения в базе данных
            entities.SaveChanges();

            // Скрываем окно добавления клиента
            ClientAddGrid.Visibility = Visibility.Hidden;

            // Отображаем окно заказов
            OrderGrid.Visibility = Visibility.Visible;
        }

        private void CancelBtn_Click(object sender, RoutedEventArgs e)
        {
            ClientAddGrid.Visibility = Visibility.Hidden;
            OrderGrid.Visibility = (Visibility)Visibility.Visible;
        }

        private void ServAddBtn_Click(object sender, RoutedEventArgs e)
        {
            ServicesTable servicesTable = new ServicesTable();
            servicesTable.SerPrice = int.Parse(ServPrice.Text);
            servicesTable.ServName = ServName.Text;
            servicesTable.ServCode = ServCode.Text;
            entities.ServicesTable.Add(servicesTable);
            entities.SaveChanges();
            ServiceAddGrid.Visibility = Visibility.Hidden;
            OrderGrid.Visibility = (Visibility)Visibility.Visible;
        }

        private void ServCancelBtn_Click(object sender, RoutedEventArgs e)
        {
            ServiceAddGrid.Visibility = Visibility.Hidden;
            OrderGrid.Visibility = (Visibility)Visibility.Visible;
        }

        public void timerBlock_tick(object sender, EventArgs e)
        {
            timerBlock.Stop();
            secondsBlock--;
        }

        //генератор капчи
        public void generatorcaptcha()
        {
            canva.Children.Clear();
            Random rnd = new Random();
            RotateTransform rotateTransform = new RotateTransform();
            TextBlock textBlock = new TextBlock();
            string captchasim = "qwertyuiopasdfghjklzxcvbnm1234567890";
            captchaText = "";
            rotateTransform.Angle = rnd.Next(-20, 20);
            for (int i = 0; i < 4; i++)
            {
                char generat = captchasim[rnd.Next(captchasim.Length)];
                captchaText += generat;

            }
            rotateTransform.Angle = rnd.Next(-20, 20);
            textBlock.Text = captchaText;
            textBlock.FontSize = 32;
            textBlock.RenderTransform = rotateTransform;
            Canvas.SetLeft(textBlock, rnd.Next(20, 100));
            Canvas.SetTop(textBlock, rnd.Next(20, 30));
            canva.Children.Add(textBlock);
            for (int i = 0; i < 600; i++)
            {

                Ellipse ellipse = new Ellipse();
                int r = rnd.Next(3, 5);
                ellipse.Height = r; ellipse.Width = r;
                Brush brus = new SolidColorBrush(Color.FromRgb((byte)rnd.Next(1, 255), (byte)rnd.Next(1, 255), (byte)rnd.Next(1, 233)));
                ellipse.Fill = brus;
                Canvas.SetLeft(ellipse, rnd.Next(250));
                Canvas.SetTop(ellipse, rnd.Next(100));

                canva.Children.Add(ellipse);
            }
            for (int i = 0; i < 2; i++)
            {
                Line line = new Line();
                line.X1 = rnd.Next(0, 50);
                line.Y1 = rnd.Next(0, 50);
                line.X2 = rnd.Next(150, 250);
                line.Y2 = rnd.Next(51, 100);
                Brush brus = new SolidColorBrush(Color.FromRgb((byte)rnd.Next(1, 255), (byte)rnd.Next(1, 255), (byte)rnd.Next(1, 233)));
                line.Stroke = brus;
                line.StrokeThickness = 3;
                canva.Children.Add(line);

            }

        }
    
   }

}

