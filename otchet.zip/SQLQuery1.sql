create table UserRole
(id int primary key, RoleName nvarchar(100))

create table LoginState
(id int primary key, LStateName nvarchar(100))

create table OrderState
(id int primary key, OStateName nvarchar(100))

create table ServicesTable
(id int primary key, ServName nvarchar(100), ServCode nvarchar(100), SerPrice decimal)

create table UserWorkers
(id int primary key, WLastName nvarchar(100), Wname nvarchar(100), WPatronomic nvarchar(100),
WLogin nvarchar(100), WPassWord nvarchar(100), WRole int references UserRole(id),
WLastLogin DateTime, WLastLoginState int references LoginState(id))

create table UserClients
(id int primary key, CLastName nvarchar(100), CName nvarchar(100), CPatronomic nvarchar(100),
CPassSer int, CPassNum int, CBirthDate Date, CIndex int, CCity nvarchar(100), CStreet nvarchar(100),
CStreetNum int, CHomeNum int, CEmail nvarchar(100), CPassWord nvarchar(100))

create table Orders
(id int primary key, OCode nvarchar(100), OCreateDate Date, OTime nvarchar(100),
OClientCode int references UserClients(id), Ostate int references OrderState(id),
OCloseDate Date, OCloseTime int)

create table OrderService
(OrderID int references Orders(id), ServiceID int references ServicesTable(id))
